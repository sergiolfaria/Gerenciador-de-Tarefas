import java.util.Date;
import java.util.*;

public class Tarefa {
    private String titulo;
    private String descricao;
    private Date dataCriacao;
    private Date dataConclusao;
    private String status;

    public Tarefa(String titulo, String descricao, Date dataCriacao, Date dataConclusao, String status) {
        this.titulo = titulo;
        this.descricao = descricao;
        this.dataCriacao = dataCriacao;
        this.dataConclusao = dataConclusao;
        this.status = status;
    }

    public String getTitulo() {
       return titulo;
    }

    public void setTitulo() { 
       this.titulo = Utils.lerTexto("digite um titulo:");
    }

    public String getdescricao() {
       return descricao;
    }

    public void setdescricao(String descricao) {
        this.descricao = Utils.lerTexto("digite um Descricao:");  
    }

    public Date getdataCriacao() {
        return dataCriacao;
    }

    public void setdataCriacao(int dataCriacao) {
        this.Data = Utils.lerInteiro ("Digite a data de criação do arquivo:");   
     }

    public Date getdataConclusao() {
        return dataConclusao;
    }

    public void setDataConclusao(Date dataConclusao) {
        this.dataConclusao = dataConclusao;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void concluirTarefa(Date dataConclusao) {
        this.dataConclusao = dataConclusao;
        this.status = "concluída";
    }
}
