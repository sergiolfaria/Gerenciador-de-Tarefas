import java.util.*;
public class Utils{
   public static int lerInteiro(String perguntaInteiro){
      Scanner teclado = new Scanner(System.in);
      System.out.print(perguntaInteiro);    
      return Integer.parseInt(teclado.nextLine());
   }
   
   public static String lerTexto(String perguntaTexto){
      Scanner teclado = new Scanner(System.in);
      System.out.print(perguntaTexto);    
      return teclado.nextLine();
   }
}
   